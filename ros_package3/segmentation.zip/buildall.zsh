#!/bin/env zsh

colcon build --packages-select segmentation
