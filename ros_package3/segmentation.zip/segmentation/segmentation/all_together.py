import rclpy
from rclpy.node import Node

from std_msgs.msg import Int64

import numpy as np
from typing import Optional
import open3d as o3d
from threading import Thread
from queue import Queue

from segmentation.Algorithms_Builtins import *
import segmentation.global_registration2 as gr
import segmentation.PointOfViewCamera as PoVC


class MergedImage(Node):
    accumulated: Optional[np.ndarray]

    def __init__(self) -> None:
        super().__init__("MergeImage")
        self.accumulated = None
        self.subscription = self.create_subscription(Int64, 'a', self.take_picture, 10)
        self.lineup = Queue(5)

    def take_picture(self, msg):
        for n in range(5):
            self.lineup.put(PoVC.main(n))
            print("click!!!")
    
    def accumulate(self):
        img = self.lineup.get(block=True)
        plane_removed_img = run_ransac(img, 0.01)
        if self.accumulated is None:
            self.accumulated = plane_removed_img
        else:
            self.accumulated = gr.main(plane_removed_img, self.accumulated)


def alternate_thread(machine):
    rclpy.spin(machine)

def main(args=None):
    rclpy.init(args=args)
    machine = MergedImage()
    camera_thread = Thread(target=alternate_thread, args=(alternate_thread, ))
    camera_thread.start()

    for _ in range(5):
        machine.accumulate()

    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(machine.accumulated)
    o3d.visualization.draw_geometries([pcd], width=800, height=600)


if __name__ == "__main__":
    main()
